# Maint-202: Hydraulic Pump Maintenance
**Machine ID:** PRESS-505
**Type:** Preventive

## Schedule
- Frequency: Monthly
- Est. Time: 2 hours

## Tools Required
- 10mm Wrench
- Hydraulic Fluid (Type H-46)
- Lint-free cloth

## Instructions
1. **Inspect Fluid Level**: Check the sight glass. Level should be between Min and Max lines.
2. **Check for Leaks**: Inspect all hoses and fittings for signs of oil.
3. **Filter Replacement**: 
    - Unscrew the filter housing.
    - Remove old element.
    - Insert new element (Part # Filt-99).
    - Tighten housing to 20Nm.
4. **Pressure Test**: Run the pump and verify pressure is stable at 150 bar.
