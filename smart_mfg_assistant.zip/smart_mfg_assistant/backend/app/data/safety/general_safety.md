# SAFETY-001: General Plant Safety and Lockout/Tagout
**Scope:** All Personnel
**Revision:** 2.0

## Personal Protective Equipment (PPE)
- **Eye Protection**: Safety glasses with side shields required at all times.
- **Foot Protection**: Steel-toed boots meeting ANSI Z41 required in production zones.
- **Hearing Protection**: Required in zones > 85dB (Marked with yellow tape).

## Lockout / Tagout (LOTO) Procedure
**Purpose**: To prevent accidental startup during service.
1.  **Notify**: Inform affected operators.
2.  **Shutdown**: Perform normal machine shutdown cycle.
3.  **Isolate**: Disconnect main energy source (Electrical disconnect, Air valve).
4.  **Lock & Tag**: Apply personal lock and tag with name/date.
5.  **Release Stored Energy**: Bleed air pressure, block gravity loads, discharge capacitors.
6.  **Verify**: Try to start machine. If it doesn't start, LOTO is successful.

## Emergency Response
- **Fire**: Pull nearest alarm. Evacuate to Assembly Point A (North Parking).
- **Injury**: Call ext 555 (Medical). Do not move victim unless in immediate danger.
