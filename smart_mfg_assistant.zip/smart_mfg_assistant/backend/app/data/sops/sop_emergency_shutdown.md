# SOP-101: Emergency Shutdown Procedure
**Machine ID:** CNC-204
**Severity:** Critical

## Safety
- Ensure all personnel are clear of the machine area.
- Do not attempt to physically brake the spindle.
- Wear safety glasses and steel-toed boots.

## Procedure
1. **Press Emergency Stop Button**: Locate the big red button on the main control panel and press it firmly.
2. **Verify Power Cut**: Ensure all status lights are off and the screen is blank.
3. **Isolate Energy**: Turn off the main disconnect switch on the electrical cabinet.
4. **Lockout/Tagout**: Apply a padlock and tag to the disconnect switch.
5. **Report**: Notify the shift supervisor immediately.

## Troubleshooting
- **Button Stuck**: If E-Stop button does not release, check for debris. Do not force it.
- **Power Remains**: If machine is still powered after E-Stop, manually flip the breaker and evacuate.
