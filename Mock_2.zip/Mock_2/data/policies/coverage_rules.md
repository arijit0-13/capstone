# Insurance Coverage Policy Rules - Auto & Property

## 1. General Coverage Conditions
- **Rule 1.1**: The policy covers damages to the insured vehicle caused by collision, theft, fire, or natural disasters (flood, earthquake).
- **Rule 1.2**: Claims must be filed within 30 days of the incident date. Late filings are subject to review and potential rejection.
- **Rule 1.3**: The policy must be active and premiums paid up to date at the time of the incident.

## 2. Exclusions
- **Rule 2.1**: Damages caused by driving under the influence of alcohol or drugs are strictly excluded.
- **Rule 2.2**: Wear and tear, mechanical breakdown, or gradual deterioration are not covered.
- **Rule 2.3**: Intentional damage caused by the policyholder or an authorized user is excluded.
- **Rule 2.4**: Use of a personal vehicle for commercial purposes (e.g., delivery, ride-share) without a commercial endorsement is excluded.

## 3. Settlement Limits & Deductibles
- **Rule 3.1**: The maximum settlement limit for property damage is ₹5,00,000 per incident.
- **Rule 3.2**: A standard deductible of ₹2,000 applies to all collision claims.
- **Rule 3.3**: For total loss, the settlement is based on the Insured Declared Value (IDV) minus applicable depreciation.

## 4. Depreciation Rules
- **Rule 4.1**: Depreciation on metal parts is calculated at 5% per year of vehicle age, up to a maximum of 50%.
- **Rule 4.2**: Plastic, rubber, and nylon parts are depreciated at a flat rate of 50%.
- **Rule 4.3**: Glass parts have 0% depreciation.

## 5. Document Requirements
- **Rule 5.1**: All claims must include a completed Claim Form, Copy of Driving License, and RC (Registration Certificate).
- **Rule 5.2**: For theft claims, a copy of the FIR (First Information Report) is mandatory.
- **Rule 5.3**: Repair estimates from an authorized workshop are required before approval.
- **Rule 5.4**: Photos of the damaged vehicle showing the license plate are required.

## 6. Fraud Indicators
- **Rule 6.1**: Claims filed less than 7 days after policy inception or renewal are flagged for "High Risk".
- **Rule 6.2**: Multiple claims (more than 2) within a 6-month period trigger a fraud review.
- **Rule 6.3**: Discrepancies between the incident description and damage photos are indicators of potential fraud.
