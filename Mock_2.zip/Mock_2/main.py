from src.graph import create_claim_graph
from src.rag import setup_rag

# Sample Claim Text
sample_claim = """
I was driving my 2020 Honda City on 15th Aug 2024 when a truck hit me from behind. 
The rear bumper and trunk are damaged. 
Repair estimate gave a cost of 45000 rupees. 
I have attached the Claim Form and my Driving License. 
I forgot to attach the RC but I have it.
Policy ID: POL-123456789.
"""

def main():
    print("Initializing System...")
    setup_rag()
    
    app = create_claim_graph()
    
    print("\nProcessing Claim...")
    print("Enter the claim text (press Enter twice to finish):")
    lines = []
    while True:
        line = input()
        if not line:
            break
        lines.append(line)
    claim_text = "\n".join(lines)
    
    if not claim_text.strip():
        print("No claim text provided using default sample.")
        claim_text = sample_claim
        
    initial_state = {"claim_text": claim_text}
    
    result = app.invoke(initial_state)
    
    print("\n" + "="*50)
    print("FINAL ADJUDICATION REPORT")
    print("="*50)
    print(result.get("final_report", "No report generated."))
    print("\nState Summary:")
    print(f"Status: {result.get('approval_status')}")
    print(f"Settlement: {result.get('settlement_estimate')}")
    print(f"Fraud Score: {result.get('fraud_score')}")

if __name__ == "__main__":
    main()
