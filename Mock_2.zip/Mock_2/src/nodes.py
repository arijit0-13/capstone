import json
import re
from typing import Dict, Any, List
from langchain_community.chat_models import ChatOllama
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import JsonOutputParser


from src.state import AgentState
from src.rag import get_policy_clauses

# Initialize LLM
llm = ChatOllama(model="mistral", temperature=0)

# --- Node 1: Parse Claim Details ---
def parse_claim_details(state: AgentState) -> Dict[str, Any]:
    print("--- Node: Parse Claim Details ---")
    claim_text = state['claim_text']
    
    # Define the expected structure for extraction
    prompt = PromptTemplate(
        template="""
        Extract the following details from the insurance claim text below.
        Return ONLY a valid JSON object with these keys: 
        - "cost" (number, repair cost mentioned)
        - "incident_type" (string, e.g., "Collision", "Theft", "Natural Disaster")
        - "policy_id" (string)
        - "submitted_docs" (list of strings, e.g., ["Claim Form", "Driving License"])
        
        Claim Text:
        {claim_text}
        
        JSON Output:
        """,
        input_variables=["claim_text"]
    )
    
    chain = prompt | llm | JsonOutputParser()
    try:
        parsed_data = chain.invoke({"claim_text": claim_text})
    except Exception as e:
        print(f"Error parsing claim: {e}")
        # Fallback manual parsing or empty defaults for robustness
        parsed_data = {
            "cost": 0,
            "incident_type": "Unknown",
            "policy_id": "Unknown",
            "submitted_docs": []
        }
    
    return {"parsed_fields": parsed_data}

# --- Node 2: Retrieve Rules (RAG) ---
def retrieve_rules_rag(state: AgentState) -> Dict[str, Any]:
    print("--- Node: Retrieve Rules RAG ---")
    incident_type = state['parsed_fields'].get('incident_type', '')
    query = f"coverage for {incident_type} and exclusions and limits"
    clauses = get_policy_clauses(query)
    return {"policy_clauses": clauses}

# --- Node 3: Check Document Completeness ---
def check_document_completeness(state: AgentState) -> Dict[str, Any]:
    print("--- Node: Check Document Completeness ---")
    submitted = [doc.lower() for doc in state['parsed_fields'].get('submitted_docs', [])]
    
    # Required docs map (could be retrieved from RAG, but hardcoding basic Logic for 'student' scope)
    # Ideally, we parse this from the "Document Requirements" section of the retrieved text.
    # For now, let's look at the retrieved policy clauses to see if it mentions requirements
    # or just use a standard list based on incident type.
    
    required = ["claim form", "driving license", "rc"]
    incident_type = state['parsed_fields'].get('incident_type', '').lower()
    
    if "theft" in incident_type:
        required.append("fir")
    
    missing = [req for req in required if not any(req in s for s in submitted)]
    
    print(f"Submitted: {submitted}")
    print(f"Missing: {missing}")
    
    return {"missing_docs": missing}

# --- Node 4: Fraud Detection ---
def fraud_detection_agent(state: AgentState) -> Dict[str, Any]:
    print("--- Node: Fraud Detection ---")
    score = 0
    reasons = []
    
    parsed = state['parsed_fields']
    cost = parsed.get('cost', 0)
    docs = parsed.get('submitted_docs', [])
    
    # Heuristic 1: High amount
    if cost > 500000: # Policy limit mention in coverage_rules
        score += 30
        reasons.append("High claim amount > 5L")
        
    # Heuristic 2: Missing photos (if mentioned in parsed docs, assumed usually 'photos' keyword)
    # Assuming 'photos' might be in docs if LLM extracted it
    if not any("photo" in d.lower() for d in docs):
        score += 20
        reasons.append("No photos submitted")
        
    # Heuristic 3: Policy ID unknown (simulated check)
    if parsed.get('policy_id') == "Unknown":
        score += 50
        reasons.append("Invalid Policy ID")
        
    # Heuristic 4: Random check for demo (or if text contains 'late')
    # Use claim text for this
    if "late" in state['claim_text'].lower() or "days after" in state['claim_text'].lower():
        score += 10
        reasons.append("Potential late filing indication")

    print(f"Fraud Score: {score} ({reasons})")
    return {"fraud_score": score}

# --- Node 5: Settlement Computation ---
def settlement_computation(state: AgentState) -> Dict[str, Any]:
    print("--- Node: Settlement Computation ---")
    # Simple logic: Cost - Deductible - Depreciation
    # Fetch limits from policy text if possible, else hardcode for this level
    
    cost = state['parsed_fields'].get('cost', 0)
    deductible = 2000 # Rule 3.2
    
    # Check limit from policy (Rule 3.1: 5L)
    limit = 500000
    
    # Depreciation (Rule 4.1 Metal 5%, let's assume 5% for simplicity default)
    # In a real app, we'd extract age of vehicle.
    depreciation_rate = 0.05 
    
    admissible_amount = min(cost, limit)
    depreciation_amt = admissible_amount * depreciation_rate
    settlement = admissible_amount - depreciation_amt - deductible
    
    if settlement < 0: 
        settlement = 0
        
    return {"settlement_estimate": settlement, "damage_cost": cost}

# --- Node 6: Final Report Builder ---
def final_report_builder(state: AgentState) -> Dict[str, Any]:
    print("--- Node: Final Report ---")
    
    fraud_score = state['fraud_score']
    missing = state['missing_docs']
    settlement = state['settlement_estimate']
    
    # Determine Status
    if len(missing) > 0:
        status = "Rejected (Missing Docs) - looped logic would normally catch this but final report shows status"
        # Actually logic is: loop -> loop -> eventually if still missing, or if we arrive here, maybe Conditional Approval?
        # The prompt says: "Loop back... when required documents are missing".
        # If we are in this node, it means we passed the check or the loop finished.
        # Let's assume if we are here and still have missing docs (maybe loop limit reached), it's Conditional.
        status = "Conditional (Pending Documents)"
    elif fraud_score > 70:
        status = "Rejected (High Fraud Risk)"
    else:
        status = "Approved"

    prompt = PromptTemplate(
        template="""
        Generate a professional adjudication note for this insurance claim.
        
        Details:
        - Status: {status}
        - Settlement Amount: ₹{settlement}
        - Fraud Score: {fraud_score}
        - Computed Damage Cost: {cost}
        - Policy Clauses Applied: {clauses}
        - Missing Docs: {missing}
        
        The note should be concise and explain the decision.
        """,
        input_variables=["status", "settlement", "fraud_score", "cost", "clauses", "missing"]
    )
    
    chain = prompt | llm
    report = chain.invoke({
        "status": status,
        "settlement": settlement,
        "fraud_score": fraud_score,
        "cost": state['damage_cost'],
        "clauses": state['policy_clauses'][:500] + "...", # Truncate for prompt limit
        "missing": ", ".join(missing) if missing else "None"
    })
    
    return {"final_report": report.content, "approval_status": status}
