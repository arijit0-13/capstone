import operator
from typing import TypedDict, List, Optional, Union, Dict, Any, Annotated

class AgentState(TypedDict):
    claim_text: str
    parsed_fields: Dict[str, Any]
    policy_clauses: str
    damage_cost: float
    missing_docs: List[str]
    fraud_score: float
    approval_status: str
    settlement_estimate: float
    final_report: str
