from langgraph.graph import StateGraph, END
from typing import Literal

from src.state import AgentState
from src.nodes import (
    parse_claim_details,
    retrieve_rules_rag,
    check_document_completeness,
    fraud_detection_agent,
    settlement_computation,
    final_report_builder
)

# Mock node to simulate user providing missing documents
def request_missing_docs_mock(state: AgentState):
    print("--- Node: Request Missing Docs (Mock User) ---")
    missing = state.get('missing_docs', [])
    print(f"Agent requested: {missing}")
    
    # Simulate user providing the missing docs
    # We update the 'parsed_fields' to include the missing ones
    current_docs = state['parsed_fields'].get('submitted_docs', [])
    updated_docs = current_docs + missing # Add them all
    
    state['parsed_fields']['submitted_docs'] = updated_docs
    print(f"User provided: {missing}")
    return {"parsed_fields": state['parsed_fields']}

def completeness_check(state: AgentState) -> Literal["fraud_detection", "request_docs"]:
    if state.get("missing_docs"):
        return "request_docs"
    return "fraud_detection"

def create_claim_graph():
    workflow = StateGraph(AgentState)

    # Add Nodes
    workflow.add_node("parse_claim_details", parse_claim_details)
    workflow.add_node("retrieve_rules_rag", retrieve_rules_rag)
    workflow.add_node("check_document_completeness", check_document_completeness)
    workflow.add_node("request_missing_docs_mock", request_missing_docs_mock)
    workflow.add_node("fraud_detection_agent", fraud_detection_agent)
    workflow.add_node("settlement_computation", settlement_computation)
    workflow.add_node("final_report_builder", final_report_builder)

    # Add Edges
    workflow.set_entry_point("parse_claim_details")
    workflow.add_edge("parse_claim_details", "retrieve_rules_rag")
    workflow.add_edge("retrieve_rules_rag", "check_document_completeness")
    
    # Conditional Edge
    workflow.add_conditional_edges(
        "check_document_completeness",
        completeness_check,
        {
            "request_docs": "request_missing_docs_mock",
            "fraud_detection": "fraud_detection_agent"
        }
    )
    
    # Loop back from request to check
    workflow.add_edge("request_missing_docs_mock", "check_document_completeness")
    
    workflow.add_edge("fraud_detection_agent", "settlement_computation")
    workflow.add_edge("settlement_computation", "final_report_builder")
    workflow.add_edge("final_report_builder", END)

    return workflow.compile()
