import os
from langchain_community.document_loaders import UnstructuredMarkdownLoader
from langchain_text_splitters import MarkdownHeaderTextSplitter, RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS

# Global vector store instance
vector_store = None

def setup_rag():
    """Initializes the RAG system by loading, chunking, and indexing the policy file."""
    global vector_store
    
    policy_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../data/policies/coverage_rules.md"))
    
    if not os.path.exists(policy_path):
        raise FileNotFoundError(f"Policy file not found at {policy_path}")

    # Read the markdown file directly
    with open(policy_path, "r", encoding="utf-8") as f:
        md_text = f.read()

    # Split by headers first to keep context
    headers_to_split_on = [
        ("#", "Header 1"),
        ("##", "Header 2"),
        ("###", "Header 3"),
    ]
    markdown_splitter = MarkdownHeaderTextSplitter(headers_to_split_on=headers_to_split_on)
    md_header_splits = markdown_splitter.split_text(md_text)

    # Then split closely by characters if needed (though headers might be enough for this small file)
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    splits = text_splitter.split_documents(md_header_splits)

    # Initialize Embeddings (Local)
    # Using a small, fast model
    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

    # Create Vector Store
    vector_store = FAISS.from_documents(splits, embeddings)
    print("RAG Setup Complete. Vector store initialized.")

def get_policy_clauses(query: str) -> str:
    """Retrieves top relevant policy clauses for a given query."""
    global vector_store
    if vector_store is None:
        setup_rag()
    
    # Retrieve top 3 chunks
    docs = vector_store.similarity_search(query, k=3)
    
    # Format results
    result_text = "\n\n".join([f"--- Clause ---\n{doc.page_content}" for doc in docs])
    return result_text

if __name__ == "__main__":
    # Test the RAG setup
    setup_rag()
    print("\nTest Retrieval for 'theft':")
    print(get_policy_clauses("vehicle theft and stolen items"))
